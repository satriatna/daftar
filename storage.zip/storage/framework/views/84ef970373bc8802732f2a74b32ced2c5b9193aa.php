
<?php $__env->startSection('content'); ?>


<section class="section">
    <div class="section-header">
      <h1>Detail Biodata Anggota</h1>
    </div>

    <div class="section-body">
      <h2 class="section-title">Detail Biodata</h2>
            
<form>
<div class="row">
  <div class="col-lg-12 col-md-12 col-sm-12">
    <div class="card">
      <div class="card-header">
        <h4 class="card-title">Biodata Akun</h4>
      </div>
      <div class="card-body">
        <div class="row">
          <div class="col-lg-6 col-md-6 col-sm-12">
            <div class="form-group">
              <div class="pull-right">
                  <img style="margin-bottom: 5px;" src="<?php echo e(asset('storage/'.$detail->photo)); ?>" width="150" height="200" class="rounded">
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">Tanggal Pembuatan</label>
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                </div>
                <input type="text" class="form-control" value="<?php echo e($detail->created_at); ?>" readonly>
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">Status User :</label>
              <div class="badge">
                <span class="badge badge-success"> Diverifikasi </span>
              </div>
            </div>
          </div>

          <div class="col-lg-6 col-md-6 col-sm-12">
            <div class="form-group">
              <label class="form-label">Nama Lengkap</label>
              <input type="text" class="form-control" value="<?php echo e($detail->name); ?>" readonly>
            </div>
            <div class="form-group">
              <label class="form-label">NIK</label>
              <div class="input-group">
                <input type="text" class="form-control" value="<?php echo e($detail->nik); ?>" readonly>
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">Email</label>
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text"><i class="far fa-envelope"></i></span>
                </div>
                <input type="text" class="form-control" value="<?php echo e($detail->user->email); ?>" readonly>
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">Nomer HP</label>
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text"><i class="fas fa-phone"></i></span>
                </div>
                <input type="text" class="form-control" value="<?php echo e($detail->phone_number); ?>" readonly>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-lg-12 col-md-12 col-sm-12">
    <div class="card">
      <div class="card-header">
        <h4 class="card-title">Biodata Lengkap</h4>
      </div>
        <div class="card-body">
          <div class="row">
            <div class="col-lg-6 col-md-6">
              <div class="form-group">
                <label class="form-label">Alamat</label>
                <textarea class="form-control" style="height:100px;" readonly><?php echo e($detail->address); ?></textarea>
              </div>
              <div class="form-group">
                <label class="form-label">Tempat Lahir</label>
                <input type="text" class="form-control" value="<?php echo e($detail->place_birth); ?>" readonly>
              </div>
              <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                  <div class="form-group">
                    <label class="form-label">Tanggal Lahir</label>
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                      </div>
                      <input type="text" class="form-control" value="<?php echo e($detail->date_birth); ?>" readonly>
                    </div>
                  </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12">
                  <div class="form-group">
                    <label class="form-label">Umur</label>
                    <div class="input-group">
                      <input type="text" class="form-control text-right" value="22" readonly>
                      <div class="input-group-append">
                        <span class="input-group-text">Tahun</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="form-group">
                <label class="form-label">Jenis Kelamin</label>
                 <input type="text" class="form-control" value="<?php echo e($detail->gender); ?>" readonly>
              </div>
              <div class="form-group">
                <label class="form-label">Status Perkawinan</label>
                <input type="text" class="form-control" value="<?php echo e($detail->married_status); ?>" readonly>
              </div>
            </div>
          </div>
        

          <div class="row">
            <div class="form-group col-6">
                <label>Province</label>
                <select name="province_id" id="wilayahProvinsi" class="form-control selectric" readonly>
                  
                </select>
              </div>
            <div class="form-group col-6">
              <label>Kabupaten</label>
              <select name="kabupaten_id" id="kabupaten_id" class="form-control selectric" readonly>

              </select>
            </div>
          </div>
          <div class="row">
            <div class="form-group col-6">
                <label>Kecamatan</label>
                <select name="kecamatan_id" id="kecamatan_id" class="form-control selectric" readonly>
                  
                </select>
              </div>
              <div class="form-group col-6">
                <label>Kelurahan</label>
                <select name="kelurahan_id" id="kelurahan_id" class="form-control selectric" readonly>
                  
                </select>
              </div>
          </div>

          <div class="row">
            <div class="col-lg-12">
              <h2 class="section-title">Riwayat Pendidikan</h2>
              <div class="table-responsive">
                
                  <table class="table table-bordered table-md">
                    <thead>
                      <tr>
                        <th class="text-center">Pendidikan Terakhir</th>
                        <th class="text-center">Tahun Lulus</th>
                        <th class="text-center">Kampus</th>
                        <th class="text-center">Pekerjaan</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                          <td class="text-center"><?php echo e($detail->education->education); ?></td>
                          <td class="text-center"><?php echo e($detail->education->graduation_year); ?></td>
                          <td class="text-center"><?php echo e($detail->education->university_name); ?></td>
                          <td class="text-center"><?php echo e($detail->education->job); ?></td>
                        </tr>
                      </tbody>
                  </table>
                
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-lg-12">
              <h2 class="section-title">Data Komunikasi</h2>
              <div class="table-responsive">
                <div class="gallery">
                  <table class="table table-bordered table-md">
                    <thead>
                      <tr>
                        <th class="text-center">Nomer Whatsapp</th>
                        <th class="text-center">Sosisal Media</th>
                        <th class="text-center">Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td class="text-center"><?php echo e($detail->wa_number); ?></td>
                        <td class="text-center"><?php echo e($detail->social_media); ?></td>
                        <td class="text-center">
                          <div class="buttons">
                            <a href="#" class="btn btn-outline-success">Hubungi</a>
                          </div>
                        </td>
                    </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-lg-12">
              <h2 class="section-title">Data Anggota Keluarga</h2>
              <div class="table-responsive">
                
                  <table class="table table-bordered table-md">
                    <thead>
                      <tr>
                        <th class="text-center">Hubungan Keluarga</th>
                        <th class="text-center">Nama Lengkap Keluarga</th>
                        <th class="text-center">Nomer Whatsapp</th>
                        <th class="text-center">Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                          <td class="text-center"><?php echo e($detail->education->education); ?></td>
                          <td class="text-center"><?php echo e($detail->education->graduation_year); ?></td>
                          <td class="text-center"><?php echo e($detail->education->university_name); ?></td>
                          <td class="text-center"><?php echo e($detail->education->job); ?></td>
                        </tr>
                      </tbody>
                  </table>
              </div>
            </div>
          </div>


          <div class="row">
            <div class="col-lg-12">
              <h2 class="section-title">Data Organisasi </h2>
              <div class="table-responsive">
                
                  <table class="table table-bordered table-md">
                    <thead>
                      <tr>
                        <th class="text-center">Pendidikan Terakhir</th>
                        <th class="text-center">Tahun Lulus</th>
                        <th class="text-center">Kampus</th>
                        <th class="text-center">Pekerjaan</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                          <td class="text-center"><?php echo e($detail->education->education); ?></td>
                          <td class="text-center"><?php echo e($detail->education->graduation_year); ?></td>
                          <td class="text-center"><?php echo e($detail->education->university_name); ?></td>
                          <td class="text-center"><?php echo e($detail->education->job); ?></td>
                        </tr>
                      </tbody>
                  </table>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-lg-6">
              <h2 class="section-title">QrCode</h2>
              <div id="qrcode" style="display:inline-block;">
                <img style="margin-bottom: 5px;" src="<?php echo e(asset('storage/'.$detail->ktp_image)); ?>" width="200" height="200" class="rounded">
              </div>
            </div>
            <div class="col-lg-6">
              <h2 class="section-title">KTP</h2>
              <div id="qrcode" style="display:inline-block;">
                <img style="margin-bottom: 5px;" src="<?php echo e(asset('storage/'.$detail->photo)); ?>" width="350" height="200" class="rounded">
              </div>
            </div>
          </div>
        </div>
        <div class="card-footer bg-whitesmoke text-center">
          <a class="btn btn-warning" href="tersangka">
            <i class="fa fa-arrow-left"></i>
            Kembali
          </a>
          <a class="btn btn-info" href="<?php echo e(route('layout_cetak')); ?>">
            <i class="fas fa-print"></i>
            Cetak Kartu
          </a>
        </div>
    </div>
  </div>
</div>
</form>

    </div>
  </section>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.utama', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pendaftaran\resources\views/admin/member_detail.blade.php ENDPATH**/ ?>